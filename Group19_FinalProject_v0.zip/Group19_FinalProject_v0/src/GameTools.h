#ifndef GAME_TOOLS_H
#define GAME_TOOLS_H

class GameTools {
private:

public:
    // 显示记分板
    void showPlayerScore();
    // 显示基础环境场景
    void showBasicEnviornment();
    // 实现Bonus场景
    void showBonus();
}

#endif